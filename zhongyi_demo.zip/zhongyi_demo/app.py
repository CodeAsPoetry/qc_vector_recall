from flask import Flask
from flask import render_template, Response, request


import json
import uuid
from pymongo import MongoClient
import datetime
import random
import math


def tid_maker():
    return '{0:%Y-%m-%d_%H:%M:%S}'.format(datetime.datetime.now())+"_" + ''.join([str(random.randint(0,9)) for i in range(12)])


connection_string = "mongodb://zyp:Zyp.2624584268@39.103.61.68:27089/zyp"
client = MongoClient(connection_string)
db = client['zyp']

app = Flask(__name__)


@app.route('/')
def hello_world():
    return render_template('index.html')


@app.route('/review')
def review():
    return render_template('data_review.html')


@app.route('/api/update_note', methods=['POST'])
def update_note():
    uid = request.get_json()["uid"]
    new_note = request.get_json()["note"]

    myquery = {"uid": uid}
    newvalues = {"$set": {"note": new_note}}

    result = db.recipes.update_one(myquery, newvalues)

    message_info = {
        "status": "failure",
        "message": "返回指定的数据集失败",
    }

    if result:
        message_info = {
            "status": "success",
            "message": "ok",
        }

    return Response(json.dumps(message_info), mimetype='application/json')


@app.route('/api/get_page_count', methods=['POST'])
def get_page_count():
    limit = 8
    sum_page = math.ceil(db.recipes.count_documents({}) / limit)
    message_info = {
        "status": "failure",
        "message": "返回指定的数据集失败",
    }
    if sum_page:
        message_info = {
            "sum_page": sum_page,
            "status": "success",
            "message": "ok",
        }

    return Response(json.dumps(message_info), mimetype='application/json')


def get_page_data(current_page, search_content=""):
    limit = 8
    sum_page = math.ceil(db.recipes.count_documents({}) / limit)
    if current_page == "":
        current_page = "1"
    all_data = []
    if search_content == "":
        page_size = 8
        if int(current_page) < 1:
            skip = 0
        elif int(current_page) > sum_page:
            skip = page_size * (sum_page - 1)
        else:
            skip = page_size * (int(current_page) - 1)
        # 返回指定的数据集的所有数据

        data = list(db.recipes.find(limit=limit).skip(skip))
        for x in data:
            del x['_id']
            all_data.append(x)
    else:
        # name中查找 search_content
        search_reg = ".*" + search_content + ".*"
        data = list(db.recipes.find({"name": {"$regex": search_reg}})) + \
               list(db.recipes.find({"recip": {"$regex": search_reg}})) + \
               list(db.recipes.find({"source": {"$regex": search_reg}})) + \
               list(db.recipes.find({"made_in": {"$regex": search_reg}})) + \
               list(db.recipes.find({"function": {"$regex": search_reg}})) + \
               list(db.recipes.find({"use_tip": {"$regex": search_reg}})) + \
               list(db.recipes.find({"attention": {"$regex": search_reg}})) + \
               list(db.recipes.find({"note": {"$regex": search_reg}}))

        for x in data:
            del x['_id']
            all_data.append(x)

    return all_data


@app.route('/api/get_table', methods=['POST'])
def get_table():
    current_page = request.get_json()["page"]
    all_data = get_page_data(current_page)


    message_info = {
        "status": "failure",
        "message": "返回指定的数据集失败",
    }
    if all_data:

        message_info = {
            "dataset": {"data": all_data},
            "status": "success",
            "message": "ok",
        }

    return Response(json.dumps(message_info), mimetype='application/json')


@app.route('/api/get_search_table', methods=['POST'])
def get_search_table():
    front_dict = request.get_json()
    current_page = front_dict["page"]
    search_content = front_dict["search_content"]
    all_data = get_page_data(current_page, search_content)
    print(all_data)

    message_info = {
        "status": "failure",
        "message": "返回指定的数据集失败",
    }
    if all_data:
        message_info = {
            "dataset": {"data": all_data},
            "status": "success",
            "message": "ok",
        }

    return Response(json.dumps(message_info), mimetype='application/json')


@app.route('/search')
def search():
    return render_template('search.html')


@app.route('/api/stock_in', methods=['POST'])
def stock_in():
    front_dict = request.get_json()

    if "name" not in front_dict.keys() or "recip" not in front_dict.keys() or "made_in" not in front_dict.keys() or \
       "function" not in front_dict.keys() or "use_tip" not in front_dict.keys():
        message_info = {
            "status": "failure",
            "message": "返回指定的数据集失败",
        }
    elif front_dict['name'] == "" or front_dict['recip'] == "" or front_dict['made_in'] == "" or \
         front_dict['function'] == "" or front_dict['use_tip'] == "":
        message_info = {
            "status": "failure",
            "message": "返回指定的数据集失败",
        }
    else:
        front_dict['uid'] = str(uuid.uuid1())
        front_dict['time'] = tid_maker()

        result = db.recipes.insert_one(front_dict)

        message_info = {
            "status": "failure",
            "message": "返回指定的数据集失败",
        }

        if result:
            message_info = {
                "status": "success",
                "message": "ok",
            }

    return Response(json.dumps(message_info), mimetype='application/json')



@app.route('/add_recipe')
def add_recipe():
    return render_template('add_recipe.html')


if __name__ == '__main__':
    print("exe")
    # app.run(debug=True)

    # 此外还可以设置其他参数，例如设置端口号，代码如下：
    app.run(
        debug=True,
        port=8000
    )
