# coding = "utf-8"

import pandas as pd
import uuid
from tqdm import tqdm
from pymongo import MongoClient
import datetime
import random


def tid_maker():
    return '{0:%Y-%m-%d_%H:%M:%S}'.format(datetime.datetime.now())+"_" + ''.join([str(random.randint(0,9)) for i in range(12)])


if __name__ == "__main__":
    connection_string = "mongodb://zyp:Zyp.2624584268@39.103.61.68:27089/zyp"
    client = MongoClient(connection_string)
    db = client['zyp']

    data_df = pd.read_excel("../data/中医方剂Excel数据表_84295.xlsx")
    data_df = data_df.fillna("")

    all_data = []
    for i in tqdm(range(len(data_df))):
        temp_dict = {
            "uid": str(uuid.uuid1()),
            "name": data_df.iloc[i]["名称"],
            "recip": data_df.iloc[i]["配方"],
            "source": data_df.iloc[i]["出处"],
            "made_in": data_df.iloc[i]["炮制"],
            "function": data_df.iloc[i]["功效"],
            "use_tip": data_df.iloc[i]["使用方法"],
            "attention": data_df.iloc[i]["注意"],
            "note": "",
            "time": tid_maker(),
        }
        all_data.append(temp_dict)

    db.recipes.insert_many(all_data)
    print("数据上传成功！！！")

    # print(db.fangji_collection.find_one())
