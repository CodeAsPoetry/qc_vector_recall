import datetime
import random


def tid_maker():
    return '{0:%Y-%m-%d_%H:%M:%S}'.format(datetime.datetime.now())+"_" + ''.join([str(random.randint(0,9)) for i in range(12)])


print(tid_maker())